from Box import Box
from Pyramid import Pyramid
from Sphere import Sphere
from Cylinder import Cylinder
x=1
while x == 1:
    shape = input("For box calculation press->1, sphere->2, pyramid->3, cylinder->4: ")
    if shape == '1':
        length = float(input("What is the length of the box:"))
        width = float(input("What is the width of the box:"))
        height = float(input("What is the height of the box:"))
        box = Box(length,width,height)
        print(f"Volume: {box.volume()} cubic units")
        print(f"Surface Area: {box.surface_area()} square units")
    
    elif shape == '2':
        radius = float(input("What is the length of the radius:"))
        sphere = Sphere(radius)
        print(f"Volume: {sphere.volume()} cubic units")
        print(f"Surface Area: {sphere.surface_area()} square units")
    
    elif shape == '3':
        length = float(input("What is the length of the pyramid:"))
        width = float(input("What is the width of the pyramid:"))
        height = float(input("What is the height of the pyramid:"))
        pyramid = Pyramid(length,width,height)
        print(f"Volume: {pyramid.volume()} cubic units")
        print(f"Surface Area: {pyramid.surface_area()} square units")
    
    elif shape == '4':
        radius = float(input("What is the length of the radius:"))
        height = float(input("What is the height of the cylinder:"))
        cylinder = Cylinder(radius,height)
        print(f"Volume: {cylinder.volume()} cubic units")
        print(f"Surface Area: {cylinder.surface_area()} square units")
    
    text = input("Would you like to calculate again?")
    if text == 'yes':
        x = 1
    else:
        x = 2