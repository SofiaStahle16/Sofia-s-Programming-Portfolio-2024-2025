import math

class Pyramid:
    def __init__(self, length, width, height):
        self.length = length
        self.width = width
        self.height = height

    def volume(self):
        base_area = self.length * self.width
        return (1/3) * base_area * self.height

    def surface_area(self):
        base_area = self.length * self.width
        slant_height = math.sqrt((self.width / 2) ** 2 + self.height ** 2)
        perimeter = 2 * (self.length + self.width)
        lateral_surface_area = (perimeter * slant_height) / 2
        return base_area + lateral_surface_area